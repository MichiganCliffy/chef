default['magic_shell']['environment'] = {}
